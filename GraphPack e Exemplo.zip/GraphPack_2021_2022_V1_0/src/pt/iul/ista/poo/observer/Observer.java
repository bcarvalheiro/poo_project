package pt.iul.ista.poo.observer;

public interface Observer {
	void update(Observed source);
}
